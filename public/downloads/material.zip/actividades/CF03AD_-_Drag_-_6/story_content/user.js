function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6dV7oKacVKy":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

